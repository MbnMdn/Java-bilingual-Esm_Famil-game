package com.example.final_project;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.Objects;


public class SingleCreatePageController extends Thread {

    ObservableList<String> repeat = FXCollections.observableArrayList("1", "2", "3", "4", "5", "6", "7", "8", "9", "10");
    int countTextFields=0;

    @FXML
    private TextField name;
    @FXML
    private ChoiceBox<String> repeat_choiceBox;
    @FXML
    private CheckBox firstName; //0
    @FXML
    private CheckBox lastName; //1
    @FXML
    private CheckBox city; //2
    @FXML
    private CheckBox country;  //3
    @FXML
    private CheckBox food;  //4
    @FXML
    private CheckBox cloth;  //5
    @FXML
    private CheckBox fruit;  //6
    @FXML
    private CheckBox car;  //7
    @FXML
    private CheckBox flower;  //8
    @FXML
    private CheckBox animal;  //9
    @FXML
    private CheckBox object;  //*
    @FXML
    private CheckBox all;
    @FXML
    private Button create;


    @FXML
    private void allChosen() {
        firstName.setSelected(true);
        lastName.setSelected(true);
        city.setSelected(true);
        country.setSelected(true);
        food.setSelected(true);
        cloth.setSelected(true);
        fruit.setSelected(true);
        car.setSelected(true);
        flower.setSelected(true);
        animal.setSelected(true);
        object.setSelected(true);
    }

/*    @FXML
    private void initialize() {
        repeat_choiceBox.setValue("1");
        repeat_choiceBox.setItems(repeat);
    }*/

    @FXML
    public String setItems() throws IOException {
        String toSend = "";
        if (firstName.isSelected()) {
            toSend += "0";
            countTextFields++;
        }
        if (lastName.isSelected()) {
            toSend += "1";
            countTextFields++;
        }
        if (city.isSelected()) {
            toSend += "2";
            countTextFields++;
        }
        if (country.isSelected()) {
            toSend += "3";
            countTextFields++;
        }
        if (food.isSelected()) {
            toSend += "4";
            countTextFields++;
        }
        if (cloth.isSelected()) {
            toSend += "5";
            countTextFields++;
        }
        if (fruit.isSelected()) {
            toSend += "6";
            countTextFields++;
        }
        if (car.isSelected()) {
            toSend += "7";
            countTextFields++;
        }
        if (flower.isSelected()) {
            toSend += "8";
            countTextFields++;
        }
        if (animal.isSelected()) {
            toSend += "9";
            countTextFields++;
        }
        if (object.isSelected()) {
            toSend += "*";
            countTextFields++;
        }

        return toSend;
    }


    static Player player;
    public void startButtonClicked() throws IOException {

        String set=setItems();
        if (countTextFields>=5) {
            player = new Player(name.getText(), set);
            System.out.println(name.getText());

            ((Stage) name.getScene().getWindow()).close();
            Stage primaryStage2 = new Stage();
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("single-game-page.fxml")));
            primaryStage2.setTitle("صفحه بازی");
            primaryStage2.setScene(new Scene(root, 800, 500));
            primaryStage2.show();
        }else{
            Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("not valid");
            errorAlert.setContentText("Choose at least 5 items");
            errorAlert.showAndWait();
        }
    }
}


