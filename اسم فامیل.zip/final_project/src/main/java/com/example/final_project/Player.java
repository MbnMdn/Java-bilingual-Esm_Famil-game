package com.example.final_project;

import java.util.ArrayList;

public class Player {
    String name;
    int port;
    String items;
    int score=0;
    static ArrayList<Player> groupPlayers=new ArrayList<>();
    static ArrayList<Player> singePlayers=new ArrayList<>();


    Player(String name,int port,String items){
        this.name=name;
        this.port=port;
        this.items=items;
        groupPlayers.add(this);
    }


    Player(String name,String items){
        this.name=name;
        this.items=items;
        singePlayers.add(this);
    }
}
