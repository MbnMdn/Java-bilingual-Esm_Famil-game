package com.example.final_project;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.io.*;
import java.util.Objects;


public class JoinPageController {
    @FXML
    Button guestEnter_btn;

    @FXML
    TextField ID;

    @FXML
    TextField port;

    @FXML
    Label portError_label;

    static MultiClient multiClient;


    @FXML
    public void guestEnterButtonClicked() throws IOException {
        ((Stage) guestEnter_btn.getScene().getWindow()).close();

        if (Objects.equals(port.getText(), "")) System.out.println("Empty");
        if (port.getText().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("خطا");
            alert.setContentText("fill out port part!!");
            alert.showAndWait();
        }


        Stage primaryStage = new Stage();
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("game-page.fxml")));
        primaryStage.setTitle("بازی");
        primaryStage.setScene(new Scene(root, 800, 500));
        primaryStage.show();

        try {
            System.out.println(port.getText());
            multiClient = new MultiClient(Integer.parseInt(port.getText()));
            //ServerCreateController.echoServer.multiClients.add(multiClient);

//.....................................................................
    // Server says everyone is connected.
            try {
                String received = multiClient.dis.readUTF();
                System.out.println("Server Says: " + received);
            }catch (Exception e){
                System.out.println("[ERROR] exception in guestEnteredButtonClicked() ");
            }
        } catch (Exception e) {
            System.out.println("error creating client.........");
            System.out.println(e.getMessage());
        }
    }
}
