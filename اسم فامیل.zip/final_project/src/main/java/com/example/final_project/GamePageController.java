package com.example.final_project;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.util.Arrays;

public class GamePageController {

    @FXML
    private TextField animal_txtField;

    @FXML
    private TextField car_txtField;

    @FXML
    private TextField city_txtField;

    @FXML
    private TextField cloth_txtField;

    @FXML
    private TextField country_textField;

    @FXML
    private TextField firstName_txtField;

    @FXML
    private TextField flower_txtField;

    @FXML
    private TextField food_txtField;

    @FXML
    private TextField fruit_txtField;

    @FXML
    private TextField lastName_txtField;

    @FXML
    private TextField object_txtField;

    @FXML
    private Button setPage;



    public void pageSettings() throws IOException {

        try {

            String received=MultiClient.getMassage();;
            System.out.println("..Server Says: " + received);

            if (received.contains("0")){
                firstName_txtField.setEditable(true);
                firstName_txtField.setPromptText("اسم");
            }
            if (received.contains("1")){
                lastName_txtField.setEditable(true);
                lastName_txtField.setPromptText("فامیل");
            }
            if (received.contains("2")){
                city_txtField.setEditable(true);
                city_txtField.setPromptText("شهر");
            }
            if (received.contains("3")){
                country_textField.setEditable(true);
                country_textField.setPromptText("کشور");
            }
            if (received.contains("4")){
                food_txtField.setEditable(true);
                food_txtField.setPromptText("غذا");
            }
            if (received.contains("5")){
                cloth_txtField.setEditable(true);
                cloth_txtField.setPromptText("پوشاک");
            }
            if (received.contains("6")){
                fruit_txtField.setEditable(true);
                fruit_txtField.setPromptText("میوه");
            }
            if (received.contains("7")){
                car_txtField.setEditable(true);
                car_txtField.setPromptText("ماشین");
            }
            if (received.contains("8")){
                flower_txtField.setEditable(true);
                flower_txtField.setPromptText("گل");
            }
            if (received.contains("9")){
                animal_txtField.setEditable(true);
                animal_txtField.setPromptText("حیوان");
            }
            if (received.contains("*")){
                object_txtField.setEditable(true);
                object_txtField.setPromptText("اشیا");
            }
        }catch (Exception e){
            System.out.println("[ERROR] exception in pageSettings() ");
            System.out.println(e.getMessage());
            System.out.println(Arrays.toString(e.getStackTrace()));
        }
    }
}