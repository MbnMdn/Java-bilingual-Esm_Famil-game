package com.example.final_project;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import javafx.util.Duration;
import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;



public class SingleGamePageController {

    ArrayList<TextField> textFields = new ArrayList<>();
    ArrayList<String> letters = new ArrayList<>();

    @FXML
    private TextField animal_txtField;

    @FXML
    private TextField car_txtField;

    @FXML
    private TextField city_txtField;

    @FXML
    private TextField cloth_txtField;

    @FXML
    private TextField country_textField;

    @FXML
    private TextField firstName_txtField;

    @FXML
    private TextField flower_txtField;

    @FXML
    private TextField food_txtField;

    @FXML
    private TextField fruit_txtField;

    @FXML
    private TextField lastName_txtField;

    @FXML
    private TextField object_txtField;

    @FXML
    private Button setPage;

    @FXML
    private Label letter;


    @FXML
    private Button finish;

    @FXML
    private Label timerLabel;



    private static final Integer STARTTIME = 40;
    private Timeline timeline;
    private IntegerProperty timeSeconds = new SimpleIntegerProperty(STARTTIME);


    @FXML
    public void pageSettings() {
        setPage.setDisable(true);
        randomLetter();

//making timer :
        timerLabel.textProperty().bind(timeSeconds.asString());
        timerLabel.setTextFill(Color.RED);
        timerLabel.setStyle("-fx-font-size: 4em;");
        if (timeline != null) {
            timeline.stop();
        }
        timeSeconds.set(STARTTIME);
        timeline = new Timeline();
        timeline.getKeyFrames().add(
                new KeyFrame(Duration.seconds(STARTTIME+1),
                        new KeyValue(timeSeconds, 0)));
        timeline.playFromStart();
        timeline.setOnFinished(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                finish.setDisable(true);
                for (TextField text : textFields) {
                    text.setEditable(false);
                    if (!text.getText().equals("")) {
                        if (!String.valueOf(text.getText().charAt(0)).equals(letter.getText())){
                            System.out.println(text.getText()+" اشتباهه ");
                            text.setStyle("-fx-border-color: red ; -fx-border-width: 2px ;");
                            try {calculateScore();
                            }catch (FileNotFoundException e) {throw new RuntimeException(e);}
                        }
                    }
                }
            }
        });



        String received = SingleCreatePageController.player.items;
//check sent items:
        if (received.contains("0")) {
            firstName_txtField.setEditable(true);
            firstName_txtField.setPromptText("اسم");
            textFields.add(firstName_txtField);
        }
        if (received.contains("1")) {
            lastName_txtField.setEditable(true);
            lastName_txtField.setPromptText("فامیل");
            textFields.add(lastName_txtField);
        }
        if (received.contains("2")) {
            city_txtField.setEditable(true);
            city_txtField.setPromptText("شهر");
            textFields.add(city_txtField);
        }
        if (received.contains("3")) {
            country_textField.setEditable(true);
            country_textField.setPromptText("کشور");
            textFields.add(country_textField);
        }
        if (received.contains("4")) {
            food_txtField.setEditable(true);
            food_txtField.setPromptText("غذا");
            textFields.add(food_txtField);
        }
        if (received.contains("5")) {
            cloth_txtField.setEditable(true);
            cloth_txtField.setPromptText("پوشاک");
            textFields.add(cloth_txtField);
        }
        if (received.contains("6")) {
            fruit_txtField.setEditable(true);
            fruit_txtField.setPromptText("میوه");
            textFields.add(fruit_txtField);
        }
        if (received.contains("7")) {
            car_txtField.setEditable(true);
            car_txtField.setPromptText("ماشین");
            textFields.add(car_txtField);
        }
        if (received.contains("8")) {
            flower_txtField.setEditable(true);
            flower_txtField.setPromptText("گل");
            textFields.add(flower_txtField);
        }
        if (received.contains("9")) {
            animal_txtField.setEditable(true);
            animal_txtField.setPromptText("حیوان");
            textFields.add(animal_txtField);
        }
        if (received.contains("*")) {
            object_txtField.setEditable(true);
            object_txtField.setPromptText("اشیا");
            textFields.add(object_txtField);
        }
    }



    public void calculateScore() throws FileNotFoundException {
        for (TextField text : textFields) {
            text.setEditable(false);
            finish.setDisable(true);
            boolean result = false;
            String t = text.getPromptText();

            switch (t) {
                case "اسم" ->   result = isIn(text.getText(), "اسم");
                case "فامیل" -> result = isIn(text.getText(), "فامیل");
                case "شهر" ->   result = isIn(text.getText(), "شهر");
                case "کشور" ->  result = isIn(text.getText(), "کشور");
                case "غذا" ->   result = isIn(text.getText(), "غذا");
                case "پوشاک" -> result = isIn(text.getText(), "پوشاک");
                case "میوه" ->  result = isIn(text.getText(), "میوه");
                case "ماشین" -> result = isIn(text.getText(), "ماشین");
                case "گل" ->    result = isIn(text.getText(), "گل");
                case "حیوان" -> result = isIn(text.getText(), "حیوان");
                case "اشیا" ->  result = isIn(text.getText(), "اشیا");
            }

            if (!result) {
                text.setText("اشتباه");
            }else
                SingleCreatePageController.player.score+=10;
        }
    }

    public void finishButtonClicked() throws IOException {
        boolean rightAnswers=false;
        timeline.stop();
        int counter=0;
        for (TextField text : textFields) {
            if (!text.getText().equals("")) {
                if (!String.valueOf(text.getText().charAt(0)).equals(letter.getText())){
                    System.out.println(text.getText()+" اشتباهه ");
                    text.setStyle("-fx-border-color: red ; -fx-border-width: 2px ;");
                    counter++;
                }
            }
        }

        if (counter==0)
            rightAnswers=true;

        if (rightAnswers) {
            calculateScore();
        }
        System.out.println(SingleCreatePageController.player.score);
        Alert errorAlert = new Alert(Alert.AlertType.INFORMATION);
        errorAlert.setHeaderText("End of Game");
        errorAlert.setContentText("Your score : " +SingleCreatePageController.player.score);
        errorAlert.showAndWait();

    }


    public void setLetters() {
        Collections.addAll(letters, "ا", "ب", "پ", "ت", "ث", "ج", "چ", "ح", "خ", "د", "ذ", "ر", "ز", "ژ", "س", "ش", "ص", "ض", "ط", "ظ", "ع", "غ", "ف", "ق", "ک", "گ", "ل", "م", "ن", "و", "ه", "ی");
    }

    private void randomLetter() {
        setLetters();
        System.out.println(letters.size());
        int min = 0, max = letters.size();
        Random random = new Random();
        int result = random.nextInt(max + min) + min;
        letter.setText(letters.get(result));
    }

    public boolean isIn(String s, String filesName) throws FileNotFoundException {
        String filename = filesName + ".txt";
        boolean found = false;
        File file = new File(filename);
        BufferedReader br = new BufferedReader(new FileReader(file));
        try {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.equals(s)) {
                    System.out.println("found");
                    found = true;
                    break;
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return found;
    }


}

