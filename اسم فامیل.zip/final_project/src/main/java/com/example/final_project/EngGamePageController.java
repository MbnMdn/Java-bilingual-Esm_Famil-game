package com.example.final_project;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import javafx.util.Duration;
import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class EngGamePageController {

    ArrayList<TextField> textFields = new ArrayList<>();
    ArrayList<String> letters = new ArrayList<>();
    private static final Integer STARTTIME = 40;
    private Timeline timeline;
    private IntegerProperty timeSeconds = new SimpleIntegerProperty(STARTTIME);


    @FXML
    private TextField animal_txt;

    @FXML
    private TextField car_txt;

    @FXML
    private TextField country_txt;

    @FXML
    private Button finish;

    @FXML
    private TextField fruit_txt;

    @FXML
    private Label letter;

    @FXML
    private TextField name_txt;

    @FXML
    private TextField object_txt;

    @FXML
    private Button setPage;

    @FXML
    private Label timerLabel;


    @FXML
    public void pageSettings() {
        setPage.setDisable(true);
        randomLetter();

//making timer :
        timerLabel.textProperty().bind(timeSeconds.asString());
        timerLabel.setTextFill(Color.RED);
        timerLabel.setStyle("-fx-font-size: 4em;");
        if (timeline != null) {
            timeline.stop();
        }
        timeSeconds.set(STARTTIME);
        timeline = new Timeline();
        timeline.getKeyFrames().add(
                new KeyFrame(Duration.seconds(STARTTIME + 1),
                        new KeyValue(timeSeconds, 0)));
        timeline.playFromStart();
        timeline.setOnFinished(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                finish.setDisable(true);
                for (TextField text : textFields) {
                    text.setEditable(false);
                    if (!text.getText().equals("")) {
                        if (!String.valueOf(text.getText().charAt(0)).equals(letter.getText())) {
                            System.out.println(text.getText() + " اشتباهه ");
                            text.setStyle("-fx-border-color: red ; -fx-border-width: 2px ;");
                            try {
                                calculateScore();
                            } catch (FileNotFoundException e) {
                                throw new RuntimeException(e);
                            }
                        }
                    }
                }
            }
        });


        String received = EnglishCreateController.player.items;
//check sent items:
        if (received.contains("0")) {
            name_txt.setEditable(true);
            name_txt.setPromptText("name");
            textFields.add(name_txt);
        }
        if (received.contains("1")) {
            country_txt.setEditable(true);
            country_txt.setPromptText("country");
            textFields.add(country_txt);
        }
        if (received.contains("2")) {
            animal_txt.setEditable(true);
            animal_txt.setPromptText("animal");
            textFields.add(animal_txt);
        }
        if (received.contains("3")) {
            fruit_txt.setEditable(true);
            fruit_txt.setPromptText("fruit");
            textFields.add(fruit_txt);
        }
        if (received.contains("4")) {
            car_txt.setEditable(true);
            car_txt.setPromptText("car");
            textFields.add(car_txt);
        }
        if (received.contains("5")) {
            object_txt.setEditable(true);
            object_txt.setPromptText("object");
            textFields.add(object_txt);
        }
    }



    public void calculateScore() throws FileNotFoundException {
        for (TextField text : textFields) {
            text.setEditable(false);
            finish.setDisable(true);
            boolean result = false;
            String t = text.getPromptText();

            switch (t) {
                case "name" ->   result = isIn(text.getText(), "name");
                case "country" -> result = isIn(text.getText(), "country");
                case "animal" ->   result = isIn(text.getText(), "animal");
                case "fruit" ->  result = isIn(text.getText(), "fruit");
                case "car" ->   result = isIn(text.getText(), "car");
                case "object" -> result = isIn(text.getText(), "object");
            }
            if (!result) {
                text.setText("Wrong!!");
            }else
                EnglishCreateController.player.score+=10;
        }
    }



    public void finishButtonClicked() throws IOException {
        boolean rightAnswers=false;
        timeline.stop();
        int counter=0;
        for (TextField text : textFields) {
            if (!text.getText().equals("")) {
                if (!String.valueOf(text.getText().charAt(0)).equals(letter.getText())){
                    System.out.println(text.getText()+" اشتباهه ");
                    text.setStyle("-fx-border-color: red ; -fx-border-width: 2px ;");
                    counter++;
                }
            }
        }

        if (counter==0)
            rightAnswers=true;

        if (rightAnswers) {
            calculateScore();
        }
        System.out.println(EnglishCreateController.player.score);
        Alert errorAlert = new Alert(Alert.AlertType.INFORMATION);
        errorAlert.setHeaderText("End of Game");
        errorAlert.setContentText("Your score : " +EnglishCreateController.player.score);
        errorAlert.showAndWait();
    }


    public void setLetters() {
        Collections.addAll(letters, "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z");
    }

    private void randomLetter() {
        setLetters();
        System.out.println(letters.size());
        int min = 0, max = letters.size();
        Random random = new Random();
        int result = random.nextInt(max + min) + min;
        letter.setText(letters.get(result));
    }

    public boolean isIn(String s, String filesName) throws FileNotFoundException {
        String filename = filesName + ".txt";
        boolean found = false;
        File file = new File(filename);
        BufferedReader br = new BufferedReader(new FileReader(file));
        try {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.equals(s)) {
                    System.out.println("found");
                    found = true;
                    break;
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return found;
    }

}
