package com.example.final_project;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

public class EnglishCreateController {

    int countTextFields=0;

    @FXML
    private CheckBox name; //0

    @FXML
    private CheckBox country; //1

    @FXML
    private CheckBox animal; //2

    @FXML
    private CheckBox fruit;  //3

    @FXML
    private CheckBox car;  //4

    @FXML
    private CheckBox object; //5

    @FXML
    private TextField userName;

    @FXML
    private Button create;





    @FXML
    public String setItems() throws IOException {
        String toSend = "";
        if (name.isSelected()) {
            toSend += "0";
            countTextFields++;
        }
        if (country.isSelected()) {
            toSend += "1";
            countTextFields++;
        }
        if (animal.isSelected()) {
            toSend += "2";
            countTextFields++;
        }
        if (fruit.isSelected()) {
            toSend += "3";
            countTextFields++;
        }
        if (car.isSelected()) {
            toSend += "4";
            countTextFields++;
        }
        if (object.isSelected()) {
            toSend += "5";
            countTextFields++;
        }

        return toSend;
    }



    static Player player;
    public void createButtonClicked() throws IOException {

        String set=setItems();
        if (countTextFields>=4) {
            player = new Player(name.getText(), set);
            System.out.println(name.getText());

            ((Stage) name.getScene().getWindow()).close();
            Stage primaryStage2 = new Stage();
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("eng-game-page.fxml")));
            primaryStage2.setTitle("Game Page");
            primaryStage2.setScene(new Scene(root, 800, 500));
            primaryStage2.show();
        }else{
            Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("not valid");
            errorAlert.setContentText("Choose at least 4 items");
            errorAlert.showAndWait();
        }
    }
}
