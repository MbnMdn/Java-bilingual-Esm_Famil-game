package com.example.final_project;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.Objects;

public class HelloController {
    @FXML
    private TextField nameText;

    @FXML
    private Button enter_btn;

    @FXML
    protected void onHelloButtonClick() throws IOException {

        Stage stage = (Stage) enter_btn.getScene().getWindow();
        stage.close();
        Stage primaryStage = new Stage();
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Join-Create.fxml")));
        primaryStage.setTitle("اسم فامیل");
        primaryStage.setScene(new Scene(root,800,500));
        primaryStage.show();
    }
}