package com.example.final_project;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.Objects;

public class SelectLanguageController {

    @FXML
    private Button english;

    @FXML
    private Button persian;

    @FXML
    private void persianButtonClicked() throws IOException {
        System.out.println("single--");
        System.out.println(persian.getText());

        ((Stage) persian.getScene().getWindow()).close();
        Stage primaryStage2 = new Stage();
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("single-create-page.fxml")));
        primaryStage2.setTitle("انفرادی");
        primaryStage2.setScene(new Scene(root,730,500));
        primaryStage2.show();

    }

    @FXML
    private void englishButtonClicked() throws IOException {
        System.out.println("single--");
        System.out.println(english.getText());

        ((Stage) english.getScene().getWindow()).close();
        Stage primaryStage2 = new Stage();
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("eng-create.fxml")));
        primaryStage2.setTitle("انفرادی");
        primaryStage2.setScene(new Scene(root,730,500));
        primaryStage2.show();

    }

}
