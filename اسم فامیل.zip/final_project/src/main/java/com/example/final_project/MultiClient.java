package com.example.final_project;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Scanner;

public class MultiClient {
    static DataInputStream dis;
    DataOutputStream dos;
    Socket s;


    public MultiClient(int port){
        try {
            System.out.println("client>> ");
            Scanner sc = new Scanner(System.in);
            InetAddress ip = InetAddress.getByName("localhost");

            s = new Socket(ip, port);
            dis = new DataInputStream(s.getInputStream());
            dos = new DataOutputStream(s.getOutputStream());

        }catch(Exception e) {
            System.out.println("Client Error"+e);
        }

            //while(true) {
/*                System.out.println(dis.readUTF());
                String tosend=sc.nextLine();
                dos.writeUTF(tosend);

                if(tosend.equals("Exit")) {
                    s.close();
                    System.out.println("Connection Closed");
                    break;
                }
                String received = dis.readUTF();
                System.out.println("Server Says: " + received);
            }
            sc.close();
            dis.close();
            dos.close();*/
        //}

    }
    public static String getMassage() throws IOException {
        System.out.println("get massage multi");
        System.out.println(dis.readUTF());
        dis.close();
        return dis.readUTF();
    }
}



