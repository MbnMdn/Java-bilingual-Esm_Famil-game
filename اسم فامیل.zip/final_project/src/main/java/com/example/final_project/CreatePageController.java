package com.example.final_project;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;

public class CreatePageController extends Thread {

    ObservableList<String> repeat = FXCollections.observableArrayList("1", "2", "3", "4", "5", "6", "7", "8", "9", "10");

    @FXML
    private TextField name;
    @FXML
    private ChoiceBox<String> repeat_choiceBox;
    @FXML
    private CheckBox firstName; //0
    @FXML
    private CheckBox lastName; //1
    @FXML
    private CheckBox city; //2
    @FXML
    private CheckBox country;  //3
    @FXML
    private CheckBox food;  //4
    @FXML
    private CheckBox cloth;  //5
    @FXML
    private CheckBox fruit;  //6
    @FXML
    private CheckBox car;  //7
    @FXML
    private CheckBox flower;  //8
    @FXML
    private CheckBox animal;  //9
    @FXML
    private CheckBox object;  //*
    @FXML
    private CheckBox all;
    @FXML
    private Button create;
    @FXML
    private CheckBox test;


    @FXML
    private void allChosen() {
        firstName.setSelected(true);
        lastName.setSelected(true);
        city.setSelected(true);
        country.setSelected(true);
        food.setSelected(true);
        cloth.setSelected(true);
        fruit.setSelected(true);
        car.setSelected(true);
        flower.setSelected(true);
        animal.setSelected(true);
        object.setSelected(true);
    }

    @FXML
    private void initialize() {
        repeat_choiceBox.setValue("1");
        repeat_choiceBox.setItems(repeat);
    }






    @FXML
    public void createButtonClicked() throws IOException {
        String toSend="";
        if(firstName.isSelected()){
            toSend+="0";
        }
        if(lastName.isSelected()){
            toSend+="1";
        }
        if(city.isSelected()){
            toSend+="2";
        }
        if(country.isSelected()){
            toSend+="3";
        }
        if(food.isSelected()){
            toSend+="4";
        }
        if(cloth.isSelected()){
            toSend+="5";
        }
        if(fruit.isSelected()){
            toSend+="6";
        }
        if(car.isSelected()){
            toSend+="7";
        }
        if(flower.isSelected()){
            toSend+="8";
        }
        if(animal.isSelected()){
            toSend+="9";
        }
        if(object.isSelected()){
            toSend+="*";
        }

            try {
                for (MultiClientHandler multiClientHandler: EchoServer.multiClientHandlers) {
                    multiClientHandler.sendMassage(toSend);
                }
            }catch (Exception e){
                System.out.println("exception in CreateButtonClicked()");
                System.out.println(e.getMessage());
            }

    }

    


    public void generator() throws IOException {
        int i=0;
        System.out.println(create.getText());
        Stage stage = (Stage) create.getScene().getWindow();
        stage.close();
/*        Stage primaryStage = new Stage();
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Join-Create.fxml")));
        primaryStage.setTitle("اسم فامیل");
        primaryStage.setScene(new Scene(root,800,500));
        primaryStage.show();*/
        //i++;

/*
        if (i==1){
            ServerSocket serverSocket= new ServerSocket(1223);
            EchoServer echoServer=new EchoServer();
            //echoServer.generate();
        }*/



    }
}
