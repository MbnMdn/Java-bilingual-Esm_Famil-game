package com.example.final_project;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class EchoServer {
    static boolean isHost=false;
    static int port=2345;
    int numOfConnections;
    int counter=0;
    ServerSocket serverSocket;
    Socket socket;
    DataInputStream dis;
    DataOutputStream dos;
    BufferedReader in ;
    PrintWriter out;

     static ArrayList<MultiClientHandler> multiClientHandlers=new ArrayList<>();

    public EchoServer(int numOfConnections) throws IOException {
        counter=0;
        this.numOfConnections=numOfConnections;
        try {
            serverSocket= new ServerSocket(port);
        }catch (Exception e){
            serverSocket= new ServerSocket(port+1);
        }
        System.out.println("your port:"+serverSocket.getLocalPort());

        System.out.println("ServerSocket: " + serverSocket);
    }

//method to accept client's request:
    public void acceptConnections() throws IOException {
        System.out.println("[SERVER] waiting for "+ numOfConnections+" clients...");
        while (counter<numOfConnections) {
             socket = null;
            try {
                socket = serverSocket.accept();

                System.out.println("A new Client is connected: " + socket);

                 dis = new DataInputStream(socket.getInputStream());
                 dos = new DataOutputStream(socket.getOutputStream());
                 in=new BufferedReader(new InputStreamReader(socket.getInputStream()));
                 out=new PrintWriter(socket.getOutputStream(),true);

                System.out.println("Assigning new thread for this Client");

                MultiClientHandler multiClientHandler=new MultiClientHandler(this,multiClientHandlers,socket,dis,dos);
                multiClientHandlers.add(multiClientHandler);
                System.out.println(multiClientHandlers.size()+" multi handlers size");
                counter++;
                System.out.println("--------------------------------------------------------------------------");
            } catch (Exception e) {
                socket.close();
                System.out.println(e);
            }
        }
        System.out.println("end of accepting");
    }

    public int getPort(EchoServer echoServer) {
        return echoServer.serverSocket.getLocalPort();
    }
}



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//clienthandler class
class MultiClientHandler extends Thread {
    String name;
    boolean set=false;
    ArrayList<MultiClientHandler> multiClientHandlerArrayList=new ArrayList<>();


    final DataInputStream dis;
    static DataOutputStream dos;
    BufferedReader in ;
    PrintWriter out;
    final Socket socket;
    static volatile int num=0;
    ArrayList<User> users=new ArrayList<>();
    EchoServer echoServer;

// constructor
    public MultiClientHandler(EchoServer e,ArrayList<MultiClientHandler> multiClientHandlerArrayList,Socket s, DataInputStream dis, DataOutputStream dos) throws IOException {
        this.echoServer=e;
        this.multiClientHandlerArrayList=multiClientHandlerArrayList;
        this.socket = s;
        this.dis = dis;
        this.dos = dos;
        this.in=new BufferedReader(new InputStreamReader(socket.getInputStream()));
        this.out=new PrintWriter(socket.getOutputStream(),true);

        User user;
        users.add(user=new User(false));
        num++;
        if (num==1){
            user.isHost=true;
            EchoServer.isHost=true;
        }
        else{
            user.isHost=false;
            EchoServer.isHost=false;
        }
        user.hostOrGuest();
    }


    public void sendMassage(String s) throws IOException {
        dos.writeUTF(s);
        dos.close();
    }
}



