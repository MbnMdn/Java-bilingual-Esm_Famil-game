package com.example.final_project;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

public class ServerCreateController {
    ObservableList<String> repeat = FXCollections.observableArrayList( "2", "3", "4", "5", "6", "7", "8", "9", "10");
    static volatile int port=1234;

    @FXML
    private ChoiceBox<String> numOfPlayers_choiceBox;

    @FXML
    private Label yourPort;

    @FXML
    Button create;

    @FXML
    Button showPort;

    @FXML
    private void initialize() {
        numOfPlayers_choiceBox.setValue("2");
        numOfPlayers_choiceBox.setItems(repeat);
    }

    //GameServer gameServer;
    static EchoServer echoServer;
    User user=new User(false);


//shows the port in label
    public void showPortClicked() throws IOException {
        echoServer=new EchoServer(Integer.parseInt(numOfPlayers_choiceBox.getValue()));
        yourPort.setText(String.valueOf(echoServer.getPort(echoServer)));
        showPort.setDisable(true);
    }


    public void createButtonClicked() throws IOException {
        create.setDisable(true);
        echoServer.acceptConnections();

        Stage stage = (Stage) create.getScene().getWindow();
        stage.close();
        Stage primaryStage2 = new Stage();
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("create-page.fxml")));
        primaryStage2.setTitle("سرورها");
        primaryStage2.setScene(new Scene(root,800,500));
        primaryStage2.show();
        //allConnected();

    }


//method to let all clients know that everyone connected successfully
    public void allConnected() throws IOException {
        try {
/*            echoServer.dos.writeUTF("[SERVER] everyone is connected now.");
            echoServer.dos.writeUTF("[SERVER] everyone is connected now.");*/
        }catch (Exception e){
            System.out.println("error allConnected()");
        }
    }


}
