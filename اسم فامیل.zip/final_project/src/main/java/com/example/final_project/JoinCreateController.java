package com.example.final_project;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.Objects;

public class JoinCreateController {
    @FXML
    private Button join;

    @FXML
    private Button create;

    @FXML
    private Button single;

    @FXML
    protected void JoinButtonClicked() throws IOException {
        System.out.println("join");
        System.out.println(join.getText());

        ((Stage) join.getScene().getWindow()).close();
        Stage primaryStage2 = new Stage();
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("join-page.fxml")));
        primaryStage2.setTitle("ورود مهمان");
        primaryStage2.setScene(new Scene(root,800,500));
        primaryStage2.show();
    }


    @FXML
    protected void singleButtonClicked() throws IOException {

        System.out.println("single--");
        System.out.println(single.getText());

        ((Stage) single.getScene().getWindow()).close();
        Stage primaryStage2 = new Stage();
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("select-language.fxml")));
        primaryStage2.setTitle("انتخاب زبان");
        primaryStage2.setScene(new Scene(root,800,500));
        primaryStage2.show();
    }
}
