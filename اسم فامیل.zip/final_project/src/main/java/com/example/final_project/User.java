package com.example.final_project;

import java.util.ArrayList;

public class User {
    private String name;
    private int score;
    boolean isHost = false;    //TRUE->HOST    FALSE->NORMAL PLAYER
    ArrayList<User> users = new ArrayList<>();
    ArrayList<MultiClientHandler> Multi = new ArrayList<>();

    public User(boolean isHost){
        this.isHost=isHost;
        users.add(this);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setHost(boolean host) {
        this.isHost = host;
    }

    public void hostOrGuest(){
        if (isHost)
            System.out.println("..........you are host..........");
        else
            System.out.println("..........you are guest..........");
    }
}
